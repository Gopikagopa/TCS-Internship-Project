package com.qa.testcase;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.qa.phptravelsuser.Userdashboard;
import com.qa.phptravelsuser.Userlogin;
import com.qa.userutilities.Userutilities;

public class Userlogintestcase extends Base{
	Userlogin userlog;
	Userdashboard userdash;
	
	@BeforeClass
	public void loginadmincase() throws InterruptedException
	{
		userlog=new Userlogin(driver);
		userdash=new Userdashboard(driver);
		Thread.sleep(2000);
		
		
	}
	
	@Test(priority=1)

	public void invaliduseremail() throws IOException, InterruptedException
	{
		
				
		String username=Userutilities.getcelldata(0,0);
		
		String pass=Userutilities.getcelldata(0,1);
		userlog.emailsend(username);
		
		userlog.passsend(pass);
		Thread.sleep(2000);
		userlog.userbuttonlog();;
		String actualurl="https://phptravels.net/login/failed";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		userlog.useremailclear();	
		userlog.userpassclear();
        Thread.sleep(2000);
        driver.navigate().back();	
	}	
	
	@Test(priority=2)
	public void invaliduserpass() throws IOException, InterruptedException
	{
		userlog.useremailclear();
		Thread.sleep(2000);
		userlog.userpassclear();

		String username=Userutilities.getcelldata(1, 0);
		
		String pass=Userutilities.getcelldata(1, 1);
		userlog.emailsend(username);
		Thread.sleep(2000);
		userlog.passsend(pass);
		Thread.sleep(2000);
		userlog.userbuttonlog();
		String actualurl="https://phptravels.net/login/failed";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		driver.navigate().back();
		
	}
	@Test(priority=3)
	public void invalid_useremailpass() throws IOException, InterruptedException
	{
		userlog.useremailclear();
		userlog.userpassclear();
		
		String username=Userutilities.getcelldata(2,0);
		
		String pass=Userutilities.getcelldata(2, 1);;
		userlog.emailsend(username);
		Thread.sleep(2000);
		userlog.passsend(pass);
		Thread.sleep(2000);
		userlog.userbuttonlog();
		String actualurl="https://phptravels.net/login/failed";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		Thread.sleep(3000);
		driver.navigate().back();
		
	}
	
	
	@Test(priority=4)
	public void nulluseremail() throws InterruptedException, IOException
	{

		userlog.useremailclear();
		userlog.userpassclear();
		String username="";
		String pass=Userutilities.getcelldata(4, 1);
		userlog.emailsend(username);
		userlog.passsend(pass);
		Thread.sleep(3000);
		userlog.userbuttonlog();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String actualurl="https://phptravels.net/login";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		//driver.navigate().back();	
		
	}
	
	@Test(priority=5)
	public void nulluserpass() throws InterruptedException, IOException
	{
		userlog.userpassclear();
		String username=Userutilities.getcelldata(5, 0);
		String pass="";
		userlog.emailsend(username);
		userlog.passsend(pass);
		Thread.sleep(3000);
		userlog.userbuttonlog();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String actualurl="https://phptravels.net/login";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		//driver.navigate().back();
	}
	
	@Test(priority=6)
	public void null_useremailpass() throws InterruptedException, IOException
	{
		
		userlog.userpassclear();
		String username="";
		String pass="";
		userlog.emailsend(username);
		userlog.passsend(pass);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		Thread.sleep(3000);
		userlog.userbuttonlog();
		Thread.sleep(3000);
		
		String actualurl="https://phptravels.net/login";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		
	}
	
	@Test(priority=7)
	public void validusercredentials() throws IOException, InterruptedException {
		
		userlog.useremailclear();
		userlog.userpassclear();
		String username=Userutilities.getcelldata(6, 0);
		String pass=Userutilities.getcelldata(6, 1);
		userlog.emailsend(username);
		userlog.passsend(pass);
		Thread.sleep(3000);
		userlog.userbuttonlog();
		Thread.sleep(3000);
		String actual="https://phptravels.net/account/dashboard";
		String expected=driver.getCurrentUrl();
		Assert.assertEquals(actual, expected);
		
		
	}
	
	@Test(priority=8)
	public void profileviewclick() throws InterruptedException
	{
	    	
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
		userdash.myprofileview();
		Thread.sleep(2000);
		userdash.profileview();
		Thread.sleep(2000);
		
	}
	
	@Test(priority=9)
	public void updateprofileaddreess() throws InterruptedException
	{
        userdash.address1clear();	
        Thread.sleep(2000);
		String address1="Marriet street ,block 10 ,10th venue";
		 Thread.sleep(3000);
		userdash.updateadress(address1);
		
	}
	
	@Test(priority=10)
	public void updateprofileaddress2() throws InterruptedException
	{
		 userdash.address2clear();
		Thread.sleep(3000);
		String address2="Germany";
		Thread.sleep(3000);
		userdash.updateadress2(address2);
		
		
	}
	
	@Test(priority=11)
	public void profileupdate() throws InterruptedException
	{
		Thread.sleep(10000);
		userdash.updateprofileclick();
		Thread.sleep(10000);
		
	}
	

	@Test(priority=12)
	public void addfundlink() throws InterruptedException
	{
		Thread.sleep(2000);
		userdash.addfundclick();
		Thread.sleep(2000);
		userdash.fundview();
		userdash.choosepaypal();
		Thread.sleep(2000);
		userdash.usdview();
		Thread.sleep(2000);
		userdash.chooseamount();
		Thread.sleep(2000);
		userdash.clickpaynow();
		Thread.sleep(2000);
		String actualpayurl="https://phptravels.net/payment/paypal";
		String expectedpayurl=driver.getCurrentUrl();
		Assert.assertEquals(actualpayurl, expectedpayurl);
		Thread.sleep(2000);
		userdash.back();
		Thread.sleep(2000);
		userdash.clickyes();
		//driver.navigate().back();
		Thread.sleep(3000);
		
	}
	
	
	@Test(priority=13)
	public void bookingdeatils() throws InterruptedException
	{
		Thread.sleep(2000);
	userdash.userbooking();
	Thread.sleep(2000);
	userdash.voucherviewclick();
	Thread.sleep(8000);
	
	Set<String>windows=driver.getWindowHandles();
	Iterator<String>It=windows.iterator();
	String parentId=It.next();
	driver.switchTo().window(parentId);
	String actualbookurl="https://phptravels.net/account/bookings";
	String expectedbookurl=driver.getCurrentUrl();
	Assert.assertEquals(actualbookurl, expectedbookurl);
	Thread.sleep(2000);
		
	}
	
	@Test(priority=14)
	public void logout() throws InterruptedException
	{
		Thread.sleep(2000);
		
		userdash.logoutclick();
		String actuallogurl="https://phptravels.net/login";
		String expectedlogurl=driver.getCurrentUrl();
		Assert.assertEquals(actuallogurl, expectedlogurl);
		Thread.sleep(2000);
		
	}
	
}



	

