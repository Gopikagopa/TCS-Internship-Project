package com.qa.testcase;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.qa.adminutilities.Adminutilities;
import com.qa.phptravelsadmin.Admindashboard;
import com.qa.phptravelsadmin.LoginAdmin;

public class Logintestcase extends Baseadmin{
	
	LoginAdmin log;
	Admindashboard admindash;
	@BeforeClass
	public void loginadmincase() throws InterruptedException
	{
		log=new LoginAdmin(driver);
		admindash=new Admindashboard(driver);
		
		Thread.sleep(2000);
		
	}
	
	@Test(priority=1)

	public void invalidemail() throws IOException, InterruptedException
	{
		
		String username=Adminutilities.getcelldata(0,0);
		
		String pass=Adminutilities.getcelldata(0,1);
		log.emailsend(username);
		
		log.passsend(pass);
		Thread.sleep(2000);
		log.buttonlog();
		String actualurl="https://phptravels.net/api/admin";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		log.emailclear();	
		log.passclear();
        Thread.sleep(2000);
        //driver.navigate().back();	
	}	
	
	@Test(priority=2)
	public void invalidpass() throws IOException, InterruptedException
	{
		//log.emailclear();
		//Thread.sleep(2000);
		//log.passclear();
		
		Thread.sleep(2000);
		String username=Adminutilities.getcelldata(1, 0);
		String pass=Adminutilities.getcelldata(1, 1);
		log.emailsend(username);
		log.passsend(pass);
		Thread.sleep(2000);
		log.buttonlog();
		String actualurl="https://phptravels.net/api/admin";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		Thread.sleep(2000);
		//driver.navigate().back();
		
	}
	@Test(priority=3)
	public void invalidemailpass() throws IOException, InterruptedException
	{
		log.emailclear();
		log.passclear();
		String username=Adminutilities.getcelldata(2,0);
		String pass=Adminutilities.getcelldata(2, 1);;
		log.emailsend(username);
		log.passsend(pass);
		Thread.sleep(2000);
		log.buttonlog();
		String actualurl="https://phptravels.net/api/admin";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		Thread.sleep(3000);
		//driver.navigate().back();
		
	}
	
	
	@Test(priority=4)
	public void nullemail() throws InterruptedException, IOException
	{

		log.emailclear();
		log.passclear();
		String username="";
		String pass=Adminutilities.getcelldata(4, 1);
		log.emailsend(username);
		log.passsend(pass);
		Thread.sleep(3000);
		log.buttonlog();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String actualurl="https://phptravels.net/api/admin";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		//driver.navigate().back();	
		
	}
	
	@Test(priority=5)
	public void nullpass() throws InterruptedException, IOException
	{
		log.passclear();
		String username=Adminutilities.getcelldata(5, 0);
		String pass="";
		log.emailsend(username);
		log.passsend(pass);
		Thread.sleep(3000);
		log.buttonlog();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String actualurl="https://phptravels.net/api/admin";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		//driver.navigate().back();
	}
	
	@Test(priority=6)
	public void nullemailpass() throws InterruptedException, IOException
	{
		
		log.passclear();
		String username="";
		String pass="";
		log.emailsend(username);
		log.passsend(pass);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		Thread.sleep(3000);
		log.buttonlog();
		Thread.sleep(3000);
		
		String actualurl="https://phptravels.net/api/admin";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		
	}
	
	@Test(priority=7)
	public void validcredentials() throws IOException, InterruptedException {
		
		log.emailclear();
		log.passclear();
		String username=Adminutilities.getcelldata(6, 0);
		String pass=Adminutilities.getcelldata(6, 1);
		log.emailsend(username);
		log.passsend(pass);
		Thread.sleep(3000);
		log.buttonlog();
		Thread.sleep(3000);
		String actual="Dashboard";
		String expected=driver.getTitle();
		Assert.assertEquals(actual, expected);
		Thread.sleep(8000);
		
		
	}
	@Test(priority=8)
	public void adminbookingclick() throws InterruptedException
	{
		Thread.sleep(2000);
		admindash.bookingclick();
		Thread.sleep(2000);
		String actualbookurl="https://phptravels.net/api/admin/bookings";
		String expectedbookurl=driver.getCurrentUrl();
		Assert.assertEquals(actualbookurl, expectedbookurl);
		  Thread.sleep(2000); 
		//String succussmsg=driver.switchTo().alert().getText();
	    //driver.switchTo().alert().dismiss();
	    //Assert.assertEquals(succussmsg, "Hello");
	  
	    
	}
	
	    
	 @Test(priority=9)
	   public void paidbooking() throws InterruptedException
	   {
		 Thread.sleep(2000);
	    admindash.bookingpaid();
	    Thread.sleep(2000);
	    admindash.paidview();
	    Thread.sleep(3000);
	   admindash.invoiceclick();
	   Thread.sleep(3000);
		Set<String>windows=driver.getWindowHandles();
		Iterator<String>It=windows.iterator();
		String parentId=It.next();
		driver.switchTo().window(parentId);
		Thread.sleep(3000);
	    String actualbookurl="paid Bookings View";
		String expectedbookurl=driver.getTitle();
		Assert.assertEquals(actualbookurl, expectedbookurl);
		Thread.sleep(2000);
	    
		
		
	}
	
	 @Test(priority=10)
	 public void cancelledbookingtest() throws InterruptedException 
	 {
		 admindash.scrollup();
		    Thread.sleep(2000);
		 admindash.cancelledbookingclick();
		 Thread.sleep(2000);
		 admindash.cancelledbookingview();
		 Thread.sleep(2000);
		 admindash.deletebooking();
		 Thread.sleep(2000);
		 String deletemsg=driver.switchTo().alert().getText();
		    //driver.switchTo().alert().dismiss();
		    driver.switchTo().alert().accept();
		    Assert.assertEquals(deletemsg, "Are you sure to delete?");
		    Thread.sleep(3000); 
		    admindash.cancelledbookingviewup();
		    Thread.sleep(3000);
		    
	 }
	 
	 @Test(priority=11)
	 public void pendingdashcountbefore() throws InterruptedException
	 {
		 //admindash.pendingclick();
		 Thread.sleep(2000);
		 String pendingcount1=admindash.pendingdashcount();
		 System.out.println("count before changing status" +pendingcount1);
		 Thread.sleep(2000);
		 //String count=admindash.pendingdashcount();
		// int value=Integer.parseInt(count);
		// System.out.println("Total count" +value);
		 
		 
	 }
	@Test(priority=12)
	public void pendingtoconfirm() throws InterruptedException
	{
		Thread.sleep(2000);
		admindash.pendingclick();
		Thread.sleep(2000);
		
		String actualpendingurl="https://phptravels.net/api/admin/bookings/pending";
		String expectedpendingurl=driver.getCurrentUrl();
		Assert.assertEquals(actualpendingurl, expectedpendingurl);
		  Thread.sleep(2000);
		//String pendingmsg=driver.switchTo().alert().getText();
	   // driver.switchTo().alert().accept();
	   // Assert.assertEquals(pendingmsg, "Hello");
	   // Thread.sleep(2000);
	    admindash.pendingdashcount();
		 System.out.println("count before changing status" +admindash.pendingdashcount() );
		 Thread.sleep(2000);
	    admindash.pendingbookingview();
	    Thread.sleep(2000);
	    admindash.pendingoptclick("pending");
	    Thread.sleep(2000);
	    admindash.confirmoptclick("confirm");
	    Thread.sleep(2000);
	    //String confirmmsg=driver.switchTo().alert().getText();
	    //driver.switchTo().alert().accept();
	    //Assert.assertEquals(confirmmsg, "Hello");
	    //Thread.sleep(2000); 
	    admindash.pendingbookingviewup();
	    Thread.sleep(2000);
	    admindash.aftercount();
		 System.out.println("count after changing status" +admindash.aftercount());
		
		Thread.sleep(2000);
	}
	@Test(priority=13)
public void websiteenable() throws InterruptedException
{
		Boolean bool=admindash.websiteclick();
		Thread.sleep(2000);
		Assert.assertEquals(bool, true);
		Thread.sleep(8000);
		Set<String>windows=driver.getWindowHandles();
		Iterator<String>It=windows.iterator();
		String parentId=It.next();
		driver.switchTo().window(parentId);
		Thread.sleep(3000);
}
	@Test(priority=14)
	public void logoutlink() throws InterruptedException
	{
		Thread.sleep(2000);
		admindash.logoutclick();
		Thread.sleep(2000);
		String actualurllogout="https://phptravels.net/api/admin";
		String expectedurllogout=driver.getCurrentUrl();
		Assert.assertEquals(actualurllogout, expectedurllogout);	
		
	}
	
}
