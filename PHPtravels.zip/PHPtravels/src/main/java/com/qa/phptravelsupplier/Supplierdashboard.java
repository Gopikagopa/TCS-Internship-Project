package com.qa.phptravelsupplier;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Supplierdashboard {
	
	WebDriver driver;
	
	@FindBy(xpath="//i[text()='menu']")
	private WebElement menu;
	@FindBy(xpath="//div[text()='Sales overview & summary']")
	private WebElement displaycontent;
	
	@FindBy(xpath="//h2[text()='Revenue Breakdown 2023']")
	private WebElement view;
	
	@FindBy(xpath="//h2[text()='Revenue Breakdown 2023']")
	private WebElement assertview;
	
	@FindBy(xpath="//div[text()='Pending Bookings']/preceding-sibling::div")
	private WebElement pendingcount;
	
	
	
	@FindBy(xpath="//div[text()='Pending Bookings']")
	private WebElement pendingview;
	
	@FindBy(xpath="//*[@id=\"layoutDrawer_content\"]/main/div/div[2]/div[2]/a/div/div/div")
	private WebElement pendingclick;
	
	//@FindBy(xpath="//div[text()='Pending Bookings']")
	//private WebElement pendingdetails;
	
	@FindBy(xpath="(//select[@id='booking_status'])[1]")
	private WebElement pendingdetailsclick;
	
	@FindBy(xpath="(//select[@id='booking_status'])[1]")
	private WebElement confirm;
	
	@FindBy(xpath="//div[text()='Dashboard']")
	private WebElement dashboardback;
	
	@FindBy(xpath="//div[text()='Dashboard']")
	private WebElement bookingdisplay;
	
	@FindBy(xpath="(//a[@href='https://phptravels.net/api/supplier/bookings'])[2]")
	private WebElement bookingsclick;


	@FindBy(xpath = "//a[@aria-controls='toursmodule']")
	private WebElement tourslink;
	
	@FindBy(xpath = "//div[@id='toursmodule']/nav/a")
	private WebElement tourslinksub;
	
	public Supplierdashboard(WebDriver driver)
	
    {
				this.driver=driver;
				PageFactory.initElements(driver, this);
				
			}
	
	public void dashview() throws InterruptedException
	{
	
	menu.click();

	
	}
	
	public String salestextdisplay()
	
	{
		String content= displaycontent.getText();
		return content;
		
	}
	
	public void viewrevenue() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,500)");
		//js.executeScript("arguments[0].scrollIntoView();",view);
		Thread.sleep(2000);
		
	
	}
	public String assertrevenue()
	{
		String revenue=assertview.getText();
		
		return revenue ;
		
	}
	
	public void scrollviewpending() throws InterruptedException
	{
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,-500)");
	
	}
	public String pendingcount()
	{
		String count=pendingcount.getText();
		return count;
		
				
	}
	
	public void clickforpendingview()
	{
		pendingview.click();
	}
	
		public void pendingdetails()
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,500)");
		
	}
		
		
	
	public void booking(String bookingpending)
	{
		Select select=new Select( pendingdetailsclick);
		select.selectByVisibleText(bookingpending);
        pendingdetailsclick.click();
		
		//bookingdetailsclick.click();
	}
	public void confirmbooking(String bookingconfirm)
	{
		Select confirmopt=new Select(confirm);
		confirmopt.selectByIndex(1);
		confirm.click();
	}
	public void backtodash()
	{
		dashboardback.click();
	}
	
	public boolean bookingtabdisplay()
	{
		
		boolean isdisplayed=bookingdisplay.isDisplayed();
		
		
		
		return isdisplayed;
		
		
	}
	public void bookingmenuclick()
	{
		bookingsclick.click();
		
	}
	public void tourtabdisplay()
	{
		tourslink.click();
		
	}
	
	public void tourtabsub()
	{
		tourslinksub.click();
	}
}
	


