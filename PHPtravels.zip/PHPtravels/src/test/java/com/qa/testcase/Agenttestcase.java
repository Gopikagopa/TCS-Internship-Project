package com.qa.testcase;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.qa.agentutilities.Agentutilities;
import com.qa.phptravelsagent.Agentdashboard;
import com.qa.phptravelsagent.Agentlogin;

public class Agenttestcase extends Base{
	
	
Agentlogin agentlog;
Agentdashboard dash;


@BeforeClass
public void loginsuppliercase() throws InterruptedException
{
	Thread.sleep(3000);
	agentlog=new Agentlogin (driver);
	dash=new Agentdashboard(driver);
	
	Thread.sleep(3000);
	
} 
@Test(priority=1)

public void invaliduseremail() throws IOException, InterruptedException
{
	
	
	String username=Agentutilities.getcelldata(0,0);
	
	String pass=Agentutilities.getcelldata(0,1);
    agentlog.emailsend(username);
    agentlog.passsend(pass);
	Thread.sleep(3000);
	 agentlog.userbuttonlog();;
	String actualurl="https://phptravels.net/login/failed";
	String expectedurl=driver.getCurrentUrl();
	Assert.assertEquals(actualurl, expectedurl);
	 agentlog.useremailclear();	
	 agentlog.userpassclear();
    Thread.sleep(3000);
    //driver.navigate().back();	
}	

@Test(priority=2)
public void invaliduserpass() throws IOException, InterruptedException
{
	//supplierlog.useremailclear();
	//Thread.sleep(2000);
	//supplierlog.userpassclear();
	
	Thread.sleep(3000);
    String username=Agentutilities.getcelldata(1,0);
	
	String pass=Agentutilities.getcelldata(1,1);
	 agentlog.emailsend(username);
	 agentlog.passsend(pass);
	Thread.sleep(2000);
	 agentlog.userbuttonlog();;
	String actualurl="https://phptravels.net/login/failed";
	String expectedurl=driver.getCurrentUrl();
	Assert.assertEquals(actualurl, expectedurl);
    Thread.sleep(2000);
   // driver.navigate().back();	
	
}
@Test(priority=3)
public void invalid_useremailpass() throws IOException, InterruptedException
{
	 agentlog.useremailclear();
	 agentlog.userpassclear();
    String username=Agentutilities.getcelldata(2,0);
	
	String pass=Agentutilities.getcelldata(2,1);
	 agentlog.emailsend(username);
	 agentlog.passsend(pass);
	Thread.sleep(2000);
	 agentlog.userbuttonlog();;
	String actualurl="https://phptravels.net/login/failed";
	String expectedurl=driver.getCurrentUrl();
	Assert.assertEquals(actualurl, expectedurl);
    Thread.sleep(2000);
    driver.navigate().back();	
    Thread.sleep(2000);
	
}


@Test(priority=4)
public void nulluseremail() throws InterruptedException, IOException
{

	 agentlog.useremailclear();
	 agentlog.userpassclear();
	String username="";
	String pass=Agentutilities.getcelldata(4, 1);
	 agentlog.emailsend(username);
	 agentlog.passsend(pass);
	Thread.sleep(2000);
	 agentlog.userbuttonlog();
	Thread.sleep(2000);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	String actualurl="https://phptravels.net/login/failed";
	String expectedurl=driver.getCurrentUrl();
	Assert.assertEquals(actualurl, expectedurl);
	//driver.navigate().back();	
	
}

@Test(priority=5)
public void nulluserpass() throws InterruptedException, IOException
{
	 agentlog.userpassclear();
	String username=Agentutilities.getcelldata(5, 0);
	String pass="";
	 agentlog.emailsend(username);
	 agentlog.passsend(pass);
	Thread.sleep(3000);
	 agentlog.userbuttonlog();
	Thread.sleep(3000);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	String actualurl="https://phptravels.net/login/failed";
	String expectedurl=driver.getCurrentUrl();
	Assert.assertEquals(actualurl, expectedurl);	
	//driver.navigate().back();
}

@Test(priority=6)
public void null_useremailpass() throws InterruptedException, IOException
{
	
	 agentlog.userpassclear();
	String username="";
	String pass="";
	 agentlog.emailsend(username);
	 agentlog.passsend(pass);
	//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
	Thread.sleep(3000);
	 agentlog.userbuttonlog();
	Thread.sleep(3000);
	
	String actualurl="https://phptravels.net/login/failed";
	String expectedurl=driver.getCurrentUrl();
	Assert.assertEquals(actualurl, expectedurl);	
	
}

@Test(priority=7)
public void validusercredentials() throws IOException, InterruptedException {
	
	 agentlog.useremailclear();
	 agentlog.userpassclear();
	String username=Agentutilities.getcelldata(6, 0);
	String pass=Agentutilities.getcelldata(6, 1);
	 agentlog.emailsend(username);
	 agentlog.passsend(pass);
	Thread.sleep(2000);
	 agentlog.userbuttonlog();
	Thread.sleep(2000);
	String actual="Dashboard - PHPTRAVELS";
	String expected=driver.getTitle();
	Assert.assertEquals(actual, expected);
	Thread.sleep(8000);
}

@Test(priority=8)
public void currencychange() throws InterruptedException
{
	Thread.sleep(3000);
	dash.currency();
	Thread.sleep(2000);
	dash.changecurrency();
	Thread.sleep(3000);
	String org="PHPTRAVELS | Travel Technology Partner - PHPTRAVELS";
	String expt=driver.getTitle();
    Assert.assertEquals(org, expt);
	Thread.sleep(8000);
}
@Test(priority=9)
public void search() throws InterruptedException
{
	Thread.sleep(3000);
	dash.searhotel();
	Thread.sleep(5000);
	dash.keyword();
	Thread.sleep(2000);
	dash.selectoption();
	Thread.sleep(2000);
	dash.searchclick();
	Thread.sleep(2000);
	String expt=dash.titleverification();
    Assert.assertEquals(expt,"Back To Search");
	driver.navigate().back();
	Thread.sleep(2000);
	
	
}
@Test(priority=10)
public void clickmenus() throws InterruptedException
{
	dash.homeclick();
	Thread.sleep(2000);
	dash.hotelclick();
	Thread.sleep(2000);
    String actalhotel="Search Hotels - PHPTRAVELS";
	String expthotel=driver.getTitle();
    Assert.assertEquals(actalhotel, expthotel);
    Thread.sleep(2000);
    dash.flightclick();
    Thread.sleep(2000);
    String actalflight="Search flights - PHPTRAVELS";
	String exptflight=driver.getTitle();
    Assert.assertEquals(actalflight, exptflight);
    Thread.sleep(2000);
    dash.tourclick();
    Thread.sleep(2000);
    String actaltour="Search Tours - PHPTRAVELS";
	String expttour=driver.getTitle();
    Assert.assertEquals(actaltour, expttour);
    Thread.sleep(2000);
    
    dash.visaclick();
    Thread.sleep(2000);
    String actalvisa="Submit Visa - PHPTRAVELS";
	String exptvisa=driver.getTitle();
    Assert.assertEquals(actalvisa, exptvisa);
    Thread.sleep(2000);
    dash.blogclick();
    Thread.sleep(2000);
    String actalblog="Blog - PHPTRAVELS";
	String exptblog=driver.getTitle();
    Assert.assertEquals(actalblog, exptblog);
    
    Thread.sleep(2000);
    dash.offersclick();
    Thread.sleep(2000);
    String actaloffer="Offers - PHPTRAVELS";
	String exptoffer=driver.getTitle();
    Assert.assertEquals(actaloffer, exptoffer);
    
    Thread.sleep(2000);
    dash.backtodestination();
    Thread.sleep(2000);
    dash.backtodashboard();
    Thread.sleep(2000);
    String actaldas="Dashboard - PHPTRAVELS";
	String exptdas=driver.getTitle();
    Assert.assertEquals(actaldas, exptdas);
    
    Thread.sleep(3000);
    
    
}

@Test(priority=11)
public void agentdashboard() throws InterruptedException
{
  Thread.sleep(2000);
  dash.bookingclick();
  Thread.sleep(2000);
  String actalbook="Bookings - PHPTRAVELS";
	String exptbook=driver.getTitle();
  Assert.assertEquals(actalbook, exptbook);
  Thread.sleep(2000);
  dash.addfundclick();
  Thread.sleep(2000);
  String actalfund="Add Funds - PHPTRAVELS";
 	String exptfund=driver.getTitle();
   Assert.assertEquals(actalfund, exptfund);
   Thread.sleep(2000);
   dash.myprofileclick();
   Thread.sleep(2000);
   String actalprofile="Profile - PHPTRAVELS";
  	String exptprofile=driver.getTitle();
    Assert.assertEquals(actalprofile, exptprofile);
    Thread.sleep(2000);
}
@Test(priority=12)
public void logoutmenu() throws InterruptedException
{
	Thread.sleep(2000);
   dash.logoutclick();
   Thread.sleep(2000);
   String actuallogurl="https://phptravels.net/login";
	String expectedlogurl=driver.getCurrentUrl();
	Assert.assertEquals(actuallogurl, expectedlogurl);
    Thread.sleep(2000);

}
}
