package com.qa.phptravelsupplier;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Supplierlogin {


			WebDriver driver;
			
			@FindBy(xpath="//input[@type='text']")
			private WebElement emailuser;
			
			@FindBy(xpath="//input[@type='password']")
			private WebElement passworduser;
			
			@FindBy(xpath="//button[@type='submit']")
			private WebElement loginuser;
			
public Supplierlogin(WebDriver driver)
			
    {
				this.driver=driver;
				PageFactory.initElements(driver, this);
				
			}

			public void emailsend(String emailbox)
			{
				emailuser.sendKeys(emailbox);
				
			}
			
			public void passsend(String pass)
			{
				passworduser.sendKeys(pass);
				
			}
			
			public void userbuttonlog() throws InterruptedException
			{
				loginuser.click();
				Thread.sleep(2000);
			}
			
			public void useremailclear()
			{
				emailuser.clear();
			}
			public void userpassclear()
			{
				passworduser.clear();
			}
			
			
		}


