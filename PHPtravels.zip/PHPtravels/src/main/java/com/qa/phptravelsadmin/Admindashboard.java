package com.qa.phptravelsadmin;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Admindashboard  {
WebDriver driver;
	
	@FindBy(xpath="(//a[@href='https://phptravels.net/api/admin/bookings'])[1]")
	private WebElement adminbooking;
	

	@FindBy(xpath="//div[text()='Paid Bookings']")
	private WebElement paid;

	@FindBy(xpath="//*[@id=\"data\"]/tbody/tr[1]/td[14]/a/i")
    private WebElement invoice;
	
	@FindBy(xpath="//div[text()='Cancelled Bookings']")
	private WebElement cancelledbooking;
    
	@FindBy(xpath="//button[@class='btn btn-danger mdc-ripple-upgraded']")
	private WebElement delete;

	@FindBy(xpath="//div[text()='Pending Bookings']")
	private WebElement pending;
	
	@FindBy(xpath="(//select[@id='booking_status'])[1]")
	private WebElement pendingoption;
	
	@FindBy(xpath="(//select[@id='booking_status'])[1]")
	private WebElement confirm;
	
	@FindBy(xpath = "//div[text()='Pending Bookings']/preceding-sibling::div")
	private WebElement dashcount;
	
	@FindBy(xpath="//*[@id=\"layoutDrawer_content\"]/main/div/div[1]/div[2]/a/div/div/div/div[1]/div[1]")
	private WebElement afterdashcount;
	
	@FindBy(xpath="//a[text()='Website']")
	private WebElement website;
	
	@FindBy(xpath="//i[text()='person']")
	private WebElement logoutselect;
	
	@FindBy(xpath="//div[text()='Logout']")
	private WebElement logout;



public Admindashboard(WebDriver driver)
{
	this.driver=driver;
	PageFactory.initElements(driver, this);
	
}

public void bookingclick()
{
	adminbooking.click();
}

public void bookingpaid()
{
	paid.click();
}
public void paidview() throws InterruptedException
{
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,500)");
	//js.executeScript("arguments[0].scrollIntoView();",view);
	Thread.sleep(2000);
	

}
public void invoiceclick()
{
	invoice.click();
}
public void scrollup() throws InterruptedException
{
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,-500)");
	//js.executeScript("arguments[0].scrollIntoView();",view);
	Thread.sleep(2000);
	

}

public void cancelledbookingclick()
{
	cancelledbooking.click();
}
public void cancelledbookingview() throws InterruptedException
{
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,500)");
	//js.executeScript("arguments[0].scrollIntoView();",view);
	Thread.sleep(2000);
	

}
public void deletebooking()
{
	delete.click();
}
public void cancelledbookingviewup() throws InterruptedException
{
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,-500)");
	
	Thread.sleep(2000);

}
public void pendingclick()
{
	pending.click();
	
}

public void pendingbookingview() throws InterruptedException
{
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,300)");


}

public void pendingoptclick(String bookingpending)
{
	Select select=new Select( pendingoption);
	select.selectByVisibleText(bookingpending);
    pendingoption.click();
	
	//bookingdetailsclick.click();
}
public void confirmoptclick(String bookingconfirm)
{
	Select confirmopt=new Select(confirm);
	confirmopt.selectByIndex(1);
	confirm.click();
}

public void pendingbookingviewup() throws InterruptedException
{
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,-300)");


}

public String pendingdashcount()
{
	return dashcount.getText();
	
}

public  String aftercount()
{
	return afterdashcount.getText();
	
}


public boolean websiteclick()
{
	
    WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(2));
    wait.until(ExpectedConditions.elementToBeClickable(website));
	website.click();
	boolean bool=website.isEnabled();
    return bool;
   
}

public void logoutclick() 
{
	
	logoutselect.click();
	
	logout.click();
}



}