package com.qa.phptravelsuser;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Userdashboard {

	WebDriver driver;
	
	@FindBy(xpath="(//a[text()=' My Profile'])[2]")
	private WebElement myprofileclick;
	
	@FindBy(name="address1")
	private WebElement addressupdate;
	
	@FindBy(xpath="//*[@id=\"fadein\"]/section[1]/div/div[2]/div/div[1]/div/div/div[2]/form/div[3]/button")
	private WebElement updateprofile;
	
	
	@FindBy(name="address2")
	private WebElement addressupdate2;
	
	
	
	@FindBy(xpath="(//a[text()=' Add Funds']//parent::li)[2]")
	private WebElement addfund;
	
	@FindBy(xpath="//input[@value='50']")
	private WebElement usdselection;
	
	@FindBy(xpath="//*[@id=\"gateway_paypal\"]")
	private WebElement paypaloptionclick;
	
	@FindBy(xpath="//*[@id=\"fadein\"]/section[1]/div/div[2]/div/div[1]/div/div/div[2]/form/div/div[2]/div/button")
	private WebElement paynow;
	
	@FindBy(xpath="//div[@class='btn-front']")
	private WebElement backtoinvoice;

	@FindBy(xpath="//a[text()='Yes']")
	private WebElement yes;

	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']/i")
	private WebElement booking;
	

	@FindBy(xpath="(//div[@class='table-content']/a)[1]")
	private WebElement viewvoucher;
	
	
	@FindBy (xpath="//a[@href='https://phptravels.net/account/add_funds']")
	private WebElement paypalback;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/logout']/i")
	private WebElement logout;
	

	
	
	
	public Userdashboard(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	public void myprofileview() throws InterruptedException
	{
		Thread.sleep(3000);
	myprofileclick.click();	
	}
	
	public void profileview() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,1000)");
		//js.executeScript("arguments[0].scrollIntoView();",view);
		Thread.sleep(2000);
		
	
	}
	
	public void address1clear()
	{
		addressupdate.clear();
	}
	public void address2clear()
	{
		addressupdate2.clear();
	}
	
	public void updateadress(String adress) throws InterruptedException
	{
		 Thread.sleep(2000);
       addressupdate.sendKeys(adress);
      
       
		
	}
	public void updateadress2(String adressno2) throws InterruptedException 
	{
	  Thread.sleep(2000);
		addressupdate2.sendKeys(adressno2);
	}
	
	public void updateprofileclick() 
	{
		
		
		updateprofile.click();
	}
	
	public void userbooking()
	{
		booking.click();
	}
	public void voucherviewclick()
	{
		viewvoucher.click();
	}
	
	public void addfundclick()
	{
		addfund.click();
	}
	
	public void fundview() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,1000)");
		//js.executeScript("arguments[0].scrollIntoView();",view);
		Thread.sleep(2000);
		
	
	}
	
	public void choosepaypal() 
	{
		
		paypaloptionclick.click();
	}
	public void usdview() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,-1000)");
		//js.executeScript("arguments[0].scrollIntoView();",view);
		Thread.sleep(2000);
		
	
	}
	
	
	public void chooseamount()
	{
		usdselection.click();
		
	}
	
	public void clickpaynow()
	{
		paynow.click();
	}
	
	public void back()
	{
		backtoinvoice.click();
	}
	public void clickyes()
	{
		yes.click();
	}
	
	/*
	public void papypalpage()
	{
		paypalback.click();
	}
	*/

   public void logoutclick()
   {
	   logout.click();
   }
}


