package com.qa.phptravelsuser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Userlogin {

		WebDriver driver;
		
		@FindBy(xpath="//input[@placeholder='Email']")
		private WebElement emailuser;
		
		@FindBy(xpath="//input[@placeholder='Password']")
		private WebElement passworduser;
		
		@FindBy(xpath="//span[text()='Login']//parent::button")
		private WebElement loginuser;
		


		public Userlogin(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);
			
		}

		public void emailsend(String emailbox)
		{
			emailuser.sendKeys(emailbox);
			
		}
		
		public void passsend(String pass)
		{
			passworduser.sendKeys(pass);
			
		}
		
		public void userbuttonlog()
		{
			loginuser.click();
		}
		
		public void useremailclear()
		{
			emailuser.clear();
		}
		public void userpassclear()
		{
			passworduser.clear();
		}
		
		
	}


