package com.qa.phptravelsagent;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Agentdashboard {
	
	WebDriver driver;
	
	@FindBy(xpath="//button[@id='currency']")
	private WebElement dropdown;
	
	@FindBy(xpath="//a[text()=' INR']")
	private WebElement indianrupee;
	

	@FindBy(xpath="//*[@id='select2-hotels_city-container' and @role='textbox']")

	private WebElement hotelsearch;
	
	
	@FindBy(xpath="//*[@id=\"fadein\"]/span/span/span[1]/input")
	private WebElement searchmenu;
	
	
	@FindBy(css=".select2-results__option")
	private WebElement options;
	

	
     @FindBy(xpath="(//button[@id='submit'])[1]")
     private WebElement searchbutton;
     
     @FindBy(xpath="//*[@id=\"fadein\"]/div[6]/a/strong")
      private WebElement backto;   
     @FindBy(xpath="//div[@class='logo']/a")
     private WebElement home;
     
     @FindBy(xpath="//a[text()='Hotels']")
     private WebElement hotel;
     
     @FindBy(xpath="//a[text()='flights']")
     private WebElement flight;
     
      
     @FindBy(xpath="//a[text()='Tours']")
 	private WebElement tours;
   
   
     @FindBy(xpath="//a[text()='visa']")
 	private WebElement visa;
   
     
     @FindBy(xpath="//a[text()='Blog']")
 	private WebElement blog;

     @FindBy(xpath="//a[text()='Offers']")
 	private WebElement offers;
     
     	 
     @FindBy(xpath="(//*[@id=\"currency\"])[2]")
 	private WebElement accdrop;

     @FindBy(xpath="//a[text()=' Dashboard']")
 	private WebElement dashb;
     
     @FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']/i")
 	private WebElement booking;
     
     @FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']/i")
 	private WebElement addfund;
 	

     @FindBy(xpath="//a[@href='https://phptravels.net/account/profile']/i")
 	private WebElement myprofile;

     @FindBy(xpath="//a[@href='https://phptravels.net/account/logout']/i")
 	private WebElement logout;

 	

public Agentdashboard(WebDriver driver)
	
    {
				this.driver=driver;
				PageFactory.initElements(driver, this);
				
			}
	
public void currency()
{
	dropdown.click();
}

public void changecurrency()
{

	indianrupee.click();
	 
}

public void searhotel()
{
	hotelsearch.click();
	
}
public  void keyword()
{
	
	searchmenu.sendKeys("win");
}

public void selectoption()
{
	
	Actions a= new Actions(driver);
	a.moveToElement(options).click().perform(); 
	
	
}
public void searchclick()
{
	searchbutton.click();
}

public String titleverification()
{
	String head=backto.getText();
	return head;
}

public void homeclick()
{
	home.click();
}
public void hotelclick()
{
	hotel.click();
}


public void flightclick()
{
	flight.click();
}

public void tourclick()
{
	tours.click();
}

public void visaclick()
{
	visa.click();
}

public void blogclick()
{
	blog.click();
}
public void offersclick()
{
	offers.click();
}

public void backtodestination()
{
	accdrop.click();
}
public void backtodashboard()
{
	dashb.click();
}
public void bookingclick()
{
	booking.click();
}
public void addfundclick()
{
	addfund.click();
}

public void myprofileclick()
{
	myprofile.click();
}

public void logoutclick()
{
	logout.click();
}
}
