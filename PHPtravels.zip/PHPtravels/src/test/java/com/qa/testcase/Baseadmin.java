package com.qa.testcase;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class Baseadmin {

	
	public static WebDriver driver;
	public static  Properties prop;
	
	@BeforeTest
	public void setup() throws IOException, InterruptedException 
	{
		FileInputStream sfile=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\config.properties");
		prop=new Properties();
		prop.load(sfile);
		driver=new ChromeDriver();
		driver.get(prop.getProperty("url2"));
		Thread.sleep(2000);
		driver.manage().window().maximize();
		
	}

	@AfterTest
	public void afterSetup()
	{
		driver.quit();
	}


}


