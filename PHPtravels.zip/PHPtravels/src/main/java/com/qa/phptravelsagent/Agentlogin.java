package com.qa.phptravelsagent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Agentlogin {

	WebDriver driver;
	
	@FindBy(xpath="//input[@placeholder='Email']")
	private WebElement emailuser;
	
	@FindBy(xpath="//input[@placeholder='Password']")
	private WebElement passworduser;
	
	@FindBy(xpath="//button[@type='submit']")
	private WebElement loginuser;
	
	
	public Agentlogin(WebDriver driver)
	
    {
				this.driver=driver;
				PageFactory.initElements(driver, this);
				
			}

			public void emailsend(String emailbox)
			{
				emailuser.sendKeys(emailbox);
				
			}
			
			public void passsend(String pass)
			{
				passworduser.sendKeys(pass);
				
			}
			
			public void userbuttonlog() throws InterruptedException
			{
				loginuser.click();
				Thread.sleep(2000);
			}
			
			public void useremailclear()
			{
				emailuser.clear();
			}
			public void userpassclear()
			{
				passworduser.clear();
			}
			
			
		}




