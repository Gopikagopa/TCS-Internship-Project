package com.qa.phptravelsadmin;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginAdmin {

	WebDriver driver;
	
	@FindBy(xpath="(//input[@name='email'])[1]")
	private WebElement email;
	
	@FindBy(xpath="//input[@name='password']")
	private WebElement password;
	
	@FindBy(xpath="//button[@type='submit']")
	private WebElement login;
	


	public LoginAdmin(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}

	public void emailsend(String emailbox)
	{
		email.sendKeys(emailbox);
		
	}
	
	public void passsend(String pass)
	{
		password.sendKeys(pass);
		
	}
	
	public void buttonlog()
	{
		login.click();
	}
	
	public void emailclear()
	{
		email.clear();
	}
	public void passclear()
	{
		password.clear();
	}
	
	
}
