package com.qa.testcase;
import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.qa.phptravelsupplier.Supplierdashboard;
import com.qa.phptravelsupplier.Supplierlogin;
import com.qa.supplierutilities.Supplierutilities;

public class Suppliertestcase extends Basesupplier{
	
	
	Supplierlogin supplierlog;
	
	Supplierdashboard dash;
	
	
	@BeforeClass
	public void loginsuppliercase() throws InterruptedException
	{
		Thread.sleep(3000);
		supplierlog=new Supplierlogin(driver);
		dash=new Supplierdashboard(driver);
		
		Thread.sleep(3000);
		
	} 
	@Test(priority=1)

	public void invaliduseremail() throws IOException, InterruptedException
	{
		
		
		String username=Supplierutilities.getcelldata(0,0);
		
		String pass=Supplierutilities.getcelldata(0,1);
	    supplierlog.emailsend(username);
		supplierlog.passsend(pass);
		Thread.sleep(2000);
		supplierlog.userbuttonlog();;
		String actualurl="https://phptravels.net/api/supplier";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		supplierlog.useremailclear();	
		supplierlog.userpassclear();
        Thread.sleep(2000);
        //driver.navigate().back();	
	}	
	
	@Test(priority=2)
	public void invaliduserpass() throws IOException, InterruptedException
	{
		//supplierlog.useremailclear();
		//Thread.sleep(2000);
		//supplierlog.userpassclear();
		
		Thread.sleep(3000);
        String username=Supplierutilities.getcelldata(1,0);
		
		String pass=Supplierutilities.getcelldata(1,1);
	    supplierlog.emailsend(username);
		supplierlog.passsend(pass);
		Thread.sleep(2000);
		supplierlog.userbuttonlog();;
		String actualurl="https://phptravels.net/api/supplier";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
        Thread.sleep(2000);
       // driver.navigate().back();	
		
	}
	@Test(priority=3)
	public void invalid_useremailpass() throws IOException, InterruptedException
	{
		supplierlog.useremailclear();
		supplierlog.userpassclear();
        String username=Supplierutilities.getcelldata(2,0);
		
		String pass=Supplierutilities.getcelldata(2,1);
	    supplierlog.emailsend(username);
		supplierlog.passsend(pass);
		Thread.sleep(2000);
		supplierlog.userbuttonlog();;
		String actualurl="https://phptravels.net/api/supplier";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
        Thread.sleep(2000);
        //driver.navigate().back();	
		
	}
	
	
	@Test(priority=4)
	public void nulluseremail() throws InterruptedException, IOException
	{

		supplierlog.useremailclear();
		supplierlog.userpassclear();
		String username="";
		String pass=Supplierutilities.getcelldata(4, 1);
		supplierlog.emailsend(username);
		supplierlog.passsend(pass);
		Thread.sleep(3000);
		supplierlog.userbuttonlog();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String actualurl="https://phptravels.net/api/supplier";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);
		//driver.navigate().back();	
		
	}
	
	@Test(priority=5)
	public void nulluserpass() throws InterruptedException, IOException
	{
		supplierlog.userpassclear();
		String username=Supplierutilities.getcelldata(5, 0);
		String pass="";
		supplierlog.emailsend(username);
		supplierlog.passsend(pass);
		Thread.sleep(3000);
		supplierlog.userbuttonlog();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String actualurl="https://phptravels.net/api/supplier";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		//driver.navigate().back();
	}
	
	@Test(priority=6)
	public void null_useremailpass() throws InterruptedException, IOException
	{
		
		supplierlog.userpassclear();
		String username="";
		String pass="";
		supplierlog.emailsend(username);
		supplierlog.passsend(pass);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		Thread.sleep(3000);
		supplierlog.userbuttonlog();
		Thread.sleep(3000);
		
		String actualurl="https://phptravels.net/api/supplier";
		String expectedurl=driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl);	
		
	}
	
	@Test(priority=7)
	public void validusercredentials() throws IOException, InterruptedException {
		
		supplierlog.useremailclear();
		supplierlog.userpassclear();
		String username=Supplierutilities.getcelldata(6, 0);
		String pass=Supplierutilities.getcelldata(6, 1);
		supplierlog.emailsend(username);
		supplierlog.passsend(pass);
		Thread.sleep(2000);
		supplierlog.userbuttonlog();
		Thread.sleep(2000);
		String actual="Dashboard";
		String expected=driver.getTitle();
		Assert.assertEquals(actual, expected);
		Thread.sleep(8000);
	}
	
	@Test(priority=8)
	public void menuclick() throws InterruptedException
	{
		
		dash.dashview();
		Thread.sleep(2000);
	}
	
	@Test(priority=9)
	public void  contentcheck() throws InterruptedException
	{
		
		String actualtext=dash.salestextdisplay();
		Assert.assertEquals(actualtext, "Sales overview & summary");
		Thread.sleep(2000);
		
		
	}
@Test(priority=10)
public void displayrevenue() throws InterruptedException
{
	Thread.sleep(2000);
	dash.viewrevenue();
	String Actual=dash.assertrevenue();
	Assert.assertEquals(Actual, "Revenue Breakdown 2023");
	
}

@Test(priority=11)
public void scrollpending() throws InterruptedException
{
	Thread.sleep(3000);
	dash.scrollviewpending();
	Thread.sleep(2000);
}


@Test(priority=12)
public void countpending() throws InterruptedException
{
	Thread.sleep(2000);
	dash.pendingcount();
	System.out.println("count="+dash.pendingcount());
	Thread.sleep(2000);
	String actualcount=dash.pendingcount();
	String expectcount="0";
	Assert.assertNotEquals(actualcount, expectcount);
	Thread.sleep(2000);
	dash.clickforpendingview();
	Thread.sleep(2000);
	dash.pendingdetails();
	Thread.sleep(2000);
	dash.booking("pending");
	Thread.sleep(2000);
	dash.confirmbooking("confirm");
	dash.scrollviewpending();
	Thread.sleep(3000);
	
}
@Test(priority=13)
public void backtodashboard() throws InterruptedException
{
	dash.backtodash();
	Thread.sleep(2000);
	String actual="Dashboard";
	String expected=driver.getTitle();
	Assert.assertEquals(actual, expected);
	Thread.sleep(2000);
	
	
}

@Test(priority=14)
public void tourdisplaycheck() throws InterruptedException
{
	Thread.sleep(2000);
	dash.tourtabdisplay();
	Thread.sleep(2000);
	
	
}
@Test(priority=15)
public void tourssubdis() throws InterruptedException
{
	Thread.sleep(2000);
	dash.tourtabsub();
	Thread.sleep(2000);
	
}

@Test(priority=16)
public void displaycheck() throws InterruptedException
{
	boolean display=dash.bookingtabdisplay();
	Assert.assertEquals(display, true);
	Thread.sleep(2000);
	dash.bookingmenuclick();
	Thread.sleep(2000);
	//driver.navigate().back();
}
}